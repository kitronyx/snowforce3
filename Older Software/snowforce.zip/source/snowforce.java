import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.serial.*; 
import controlP5.*; 
import peasy.*; 
import java.awt.event.*; 
import java.io.BufferedWriter; 
import java.io.FileWriter; 
import java.util.Arrays; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class snowforce extends PApplet {

/* Snowforce.pde
 Visualization software for the Snowboard - an all-in-one touch development platform
 Copyright (c) 2014-2017 Kitronyx http://www.kitronyx.com
 contact@kitronyx.com
 GPL V3.0
 */
 // import the Processing serial library




ControlP5 cp5;
PeasyCam cam;
CameraState state;
DataLogger dataLogger;

// icon and title
final static String ICON = "snowforce.png";
final static String TITLE = "snowforce";

// max ad value to adopt
final int MAXVAL = 255;
int MAXDRIVE = 16;
int MAXSENSE = 10;

// configuration parameters read from INI
String DEVICE = "snowboard";
int NDRIVE;
int NSENSE;
int INTERPSCALE;
String PORT; // com port
int[] ACTIVERANGE; // actual sensor data to show [rmin, rmax, cmin, cmax]
int[] driveindex;
int[] senseindex;
int nconfigv1 = 13; // number of configuration parameters in config v.1
int nconfigv2 = 14; // number of configuration parameters in config v.2
int SENSOR_WIDTH = -1; // mm
int SENSOR_HEIGHT = -1; // mm

// general application information
boolean do_data_acquisition = false;
boolean do_data_log = false;
Serial a_port;
String comPort;
int baudRate=115200;
boolean is_serial_read = false;
String packetType="string";
String requestCommand = "A";

// data and statistics
int[][] data;
int[][] data_to_draw;
int[][] backgroundNoise;
int[][] out_interp2d;
int minFrame = 0;
int maxFrame = 0;
int sumFrame = 0;
int current_time = millis();
float sensorFrameRate;
String strSensorData;

// camera control parameters
int sx; // width of one grid cell
int sy; // height of one grid cell
float eyeX, eyeY, eyeZ; // camera eye position
float transX, transY; // translation of 3d graphic
float oldMouseX, newMouseX, mouseDx;
float oldMouseY, newMouseY, mouseDy;

// preprocessing - data and visualization control
boolean fillGrid; // fill grid or not
boolean doBackgroundNoiseFiltering;
// thresholinding in visulatization.
int nThresholdValue = 6;
int[] thresholdValue = {
    0, 10, 20, 30, 40, 50
};
int thresholdValueIndex = 1;

// misc.
int visualizationType = 2; // 2 (2D) or 3 (3D).
boolean printDebugInfo = false;
int plotMethod = 0; // interp, separate interp, and cylinder
boolean drawGrid = true;
float zscale = 8; // control z axis scale of graph
boolean xDir = true;
boolean yDir = true;
boolean zDir = true;
boolean drawHeatmap = false;
boolean drawMessages = true;
boolean showMeasurement = false;
// useOpenGL = true to use 3D feature of snowforce.
boolean useOpenGL = false;
int nLogInterval = 5;
int[] logInterval = {1, 100, 1000, 2000, 3000};
int logIntervalIndex = 0;
int drawCount = 0;
int tstart = 0;
boolean squarePlot = false;
int bytestreamoffset = 0;

public void setup()
{
    // initialize screen
    if (useOpenGL == true) size(800, 600, P3D);
    else size(800, 600);

    // look at width/2, height/2, 0 at distance 1000
    cam = new PeasyCam(this, width/2, height/2, 0, (width/800)*1000);
    cam.setMinimumDistance(50);
    cam.setMaximumDistance(15500);
    state = cam.getState();

    changeAppIcon( loadImage(ICON) );
    changeAppTitle(TITLE);
    
    fillGrid = true;
    doBackgroundNoiseFiltering = false;
    
    // read configuration
    readINI(null); // read default ini files
    applyINI();
    
    
    setupSerial(); // initialize serial communication.
    setupControl(); // setup gui controls
    
    cam.lookAt(frame.getWidth()/2, frame.getHeight()/2, 0, (width/800)*1000);
    
    frameRate(60);
}

public void readINI(File selection)
{
    String[] config;
    String delims = "=";
    String[] tokens;
    String[] subtokens;
    boolean isStandardDevice = false;
    
    int nconfig = nconfigv1;
    if (selection == null) config = loadStrings("snowboard_1610.ini");
    else
    {
        config= loadStrings(selection.getAbsolutePath());
        nconfig = config.length;
    }
        
    tokens = config[0].split(delims);
    DEVICE = tokens[1];
    if (DEVICE.equals("snowboard"))
    {
        MAXDRIVE = 16;
        MAXSENSE = 10;
        isStandardDevice = true;
    }
    else if (DEVICE.equals("mc1509"))
    {
        MAXDRIVE = 48;
        MAXSENSE = 48;
        isStandardDevice = true;
    }
    else if (DEVICE.equals("mc1600s"))
    {
        MAXDRIVE = 48;
        MAXSENSE = 48;
        isStandardDevice = true;
    }
    else if  (DEVICE.equals("mc1506"))
    {
        MAXDRIVE = 24;
        MAXSENSE = 24;
        isStandardDevice = true;
    }
    else
    {
        isStandardDevice = false;
    }
    subtokens = split(tokens[1], ',');
    if (subtokens.length == 3)
    {
        SENSOR_WIDTH = PApplet.parseInt(subtokens[1]);
        SENSOR_HEIGHT = PApplet.parseInt(subtokens[2]);
    }
    

    tokens = config[1].split(delims);
    NDRIVE = PApplet.parseInt(tokens[1]);

    tokens = config[2].split(delims);
    NSENSE = PApplet.parseInt(tokens[1]);
    
    if (isStandardDevice == false)
    {
        MAXDRIVE = NDRIVE;
        MAXSENSE = NSENSE;
    }

    tokens = config[3].split(delims);
    ACTIVERANGE = PApplet.parseInt(split(tokens[1], ','));

    tokens = config[4].split(delims);
    INTERPSCALE = PApplet.parseInt(tokens[1]);

    tokens = config[5].split(delims);
    PORT = tokens[1];
    
    tokens = config[6].split(delims);
    baudRate = PApplet.parseInt(tokens[1]);

    tokens = config[7].split(delims);
    xDir = PApplet.parseBoolean(tokens[1]);

    tokens = config[8].split(delims);
    yDir = PApplet.parseBoolean(tokens[1]);

    tokens = config[9].split(delims);
    zDir = PApplet.parseBoolean(tokens[1]);

    tokens = config[10].split(delims);
    driveindex = PApplet.parseInt(split(tokens[1], ','));

    tokens = config[11].split(delims);
    senseindex = PApplet.parseInt(split(tokens[1], ','));
    
    tokens = config[12].split(delims);
    packetType = tokens[1];
    
    if (nconfig == nconfigv2)
    {
        tokens = config[13].split(delims);
        requestCommand = tokens[1];
    }
    else
    {
        requestCommand = "A"; // default request command
    }
    
}

public void applyINI()
{
    // initialize module variables
    data = new int[NDRIVE][NSENSE];
    int nrow_data_to_draw = ACTIVERANGE[1]-ACTIVERANGE[0]+1;
    int ncol_data_to_draw = ACTIVERANGE[3]-ACTIVERANGE[2]+1;
    data_to_draw = new int[nrow_data_to_draw][ncol_data_to_draw];
    backgroundNoise = new int[NDRIVE][NSENSE];
    out_interp2d = new int[nrow_data_to_draw*INTERPSCALE][ncol_data_to_draw*INTERPSCALE];
    //out_interp2d = new int[ncol_data_to_draw*INTERPSCALE][nrow_data_to_draw*INTERPSCALE];

    for (int i = 0; i < data.length; i++)
    {
        for (int j = 0; j < data[i].length; j++)
        {
            data[i][j] = 0;
            backgroundNoise[i][j] = 0;
        }
    }

    // grid setting
    sx = width/data.length;
    sy = height/data[0].length;

    sensorFrameRate = 0;
    strSensorData = "";

    dataLogger = new DataLogger();
}


public void setupSerial()
{
    if (Serial.list().length == 0) // no device.
    {
        comPort = "Not Found";
        println("Device not attached.");
    } else
    {
        if (PORT.equals("auto")) comPort = Serial.list()[0];
        else comPort = PORT;

        println(comPort);
    }
}

public void startSerial()
{
    if (comPort.equals("Not Found"))
    { // create virtual data if serial port or device is not available.
        for (int i = 0; i < data.length; i++)
        {
            for (int j = 0; j < data[0].length; j++)
            {
                data[i][j] = PApplet.parseInt(random(0, 50));
            }
        }
    } else
    {
        // serial port initialization with error handling
        a_port = new Serial(this, comPort, baudRate, 'N', 8, 1);

        println("Initializing communication");
        int comm_init_start = millis();
        int comm_init_wait_time = 5000; // ms;
    }
}

public void draw()
{
    if (0 == drawCount % logInterval[logIntervalIndex]) tstart = millis();
    
    // read data from the Snowboard
    if (do_data_acquisition && !comPort.equals("Not Found")) getData(); 

    

    background(70, 100, 255);

    drawGraph();

    if (drawMessages == true)
    {
        // beginHUD() and endHUD() are for avoiding interference by PeasyCam
        // while drawing texts.
        // http://forum.processing.org/two/discussion/4470/solved-how-to-use-peasy-cam-without-affecting-the-text-position/p1
        
        
        
        if (useOpenGL == true) cam.beginHUD();
        drawLogo();
        drawHelp();
        drawInfo();
        drawCopyright();
        if (showMeasurement == true) drawMeasurement(); // sensor 2D measurement
        drawCopyright();

        if (useOpenGL == true) cam.endHUD();
        drawControl();
    }

    drawCount++;
    
    if (0 == drawCount % logInterval[logIntervalIndex])
    {
        int telapsed = millis() - tstart;
        dataLogger.setTs(telapsed);
        dataLogger.logData(data);
        drawCount = 0;
    }
}

// get heatmap rgb values
public int[] jet(float min, float max, float x)
{
    float r, g, b;
    float dv;

    r = 1;
    g = 1;
    b = 1;

    if (x < min) x = min;
    if (x > max) x = max;
    dv = max - min;

    if (x < (min + 0.25f*dv))
    {
        r = 0;
        g = 4 * (x - min) / dv;
    } else if (x < (min + 0.5f * dv))
    {
        r = 0;
        b = 1 + 4 * (min + 0.25f * dv - x) / dv;
    } else if (x < (min + 0.75f * dv))
    {
        r = 4 * (x - min - 0.5f * dv) / dv;
        b = 0;
    } else
    {
        g = 1 + 4 * (min + 0.75f * dv - x) / dv;
        b = 0;
    }

    int[] rgb = new int[3];
    rgb[0] = PApplet.parseInt(255*r);
    rgb[1] = PApplet.parseInt(255*g);
    rgb[2] = PApplet.parseInt(255*b);
    return rgb;
}

// 2D visualization (heatmap)
public void visualization2D()
{
    // interp2d will output `out_interp2d`.
    interp2d(data_to_draw);

    int nrowinterp = out_interp2d.length;
    int ncolinterp = out_interp2d[0].length;
    
    int nrow = nrowinterp - (INTERPSCALE-1);
    int ncol = ncolinterp - (INTERPSCALE-1);

    //PImage img = createImage(nrow, ncol, RGB);
    PImage img = createImage(ncol, nrow, RGB);

    for (int i = 0; i < nrow; i++)
    {
        for (int j = 0; j < ncol; j++)
        {
            int[] rgb = jet(0, 255, PApplet.parseFloat(out_interp2d[i][j]));
            img.pixels[i*ncol + j] = color(rgb[0], rgb[1], rgb[2]);//color(204, 153, 0, out_interp2d[i][j]);
        }
    }
    
    int w, h;
    
    if (squarePlot == true)
    {
        w = 480;
        h = 480;
    } else if (nrow < ncol)
    {
        w = 480;
        if ( (SENSOR_WIDTH != -1) && (SENSOR_HEIGHT != -1) )
        {
            h = w * SENSOR_HEIGHT / SENSOR_WIDTH;
        }
        else
        {
            h = w * nrow / ncol;
        }
    } else if (nrow > ncol)
    {
        h = 480;
        if ( (SENSOR_WIDTH != -1) && (SENSOR_HEIGHT != -1) )
        {
            w = h * SENSOR_WIDTH / SENSOR_HEIGHT;
        }
        else
        {
            w = h * ncol / nrow;
        } 
    } else
    {
        w = 480;
        h = 480;
    }

    int x0 = (width-w)/2;
    int y0 = (height-h)/2;

    img.resize(w, h);
    image(img, x0, y0);
}


public void visualization3D()
{
    switch (plotMethod)
    {
    case 0: // 1) Full interpolation
        interp2d(data_to_draw);
        surf(out_interp2d, drawGrid, zDir);
        break;

    case 1: // 2) Fill 0 between data to separte each cell
        // pending 2 zero rows/cols on upper and left edge.
        // if not, interpolated graph is shifted to upper and left direction.
        // probably due to the inherent characterstics of bicubic interpolation?
        int[][] data_to_draw_fill0 = new int[2*data_to_draw.length+2][2*data_to_draw[0].length+2];
        for (int i = 0; i < data_to_draw_fill0.length; i++)
        {
            for (int j = 0; j < data_to_draw_fill0[0].length; j++)
            {
                data_to_draw_fill0[i][j] = 0;
            }
        }

        for (int i = 0; i < data_to_draw.length; i++)
        {
            for (int j = 0; j < data_to_draw[0].length; j++)
            {
                data_to_draw_fill0[2*(i+1)][2*(j+1)] = data_to_draw[i][j];
            }
        }

        interp2d(data_to_draw_fill0);

        surf(out_interp2d, drawGrid, zDir);
        break;

    // obsolete. no longer supported.
    case 2: // 3) Cylinder plot
        interp2d(data_to_draw);
        for (int i = 0; i < out_interp2d.length; i++)
        {
            for (int j = 0; j < out_interp2d[0].length; j++)
            {
                out_interp2d[i][j] = 0;
            }
        }

        surf(out_interp2d, drawGrid, zDir);

        int[][] ccolor = {
            {
                255, 0, 0
            }
            , {
                0, 255, 0
            }
            , {
                0, 0, 255
            }
            , {
                255, 0, 255
            }
        };
        int k = 0;
        for (int i = 0; i < data_to_draw.length; i++)
        {
            for (int j = 0; j < data_to_draw[0].length; j++)
            {
                int color_index = k % ccolor.length;
                float x = width / (data_to_draw[0].length + 1) * (j + 1);
                float y = height / (data_to_draw.length + 1) * (i + 1);
                float r = width / ( 4*(data_to_draw[0].length + 1) );
                // 0 height cylider causes overlapped ugly plot.
                if (data_to_draw[i][j] > 0) drawCylinder(x, y, 30, r, r, data_to_draw[i][j], ccolor[color_index]);
                k++;
            }
        }
        break;
    }
}

// data acquisition
public boolean getData()
{
    // lock buffer.
    is_serial_read = true;

    // request data
    //a_port.write("A");
    if  (packetType.equals("bytestream")){
        
      }
    else{
      a_port.write(requestCommand);
    }
    
    // uncomment this line and change delay time if
    // your pc does not communicate with mc1509.
    // this is a case for users who use mac os.
    //delay(50);
    
    // read the serial buffer:
    int [] sensors = new int[NDRIVE*NSENSE];
    if (packetType.equals("string"))
    {
        String myString = a_port.readStringUntil('\n');
        if (myString == null) return false;
    
        // if you got any bytes other than the linefeed:
        myString = trim(myString);
    
        // split the string at the commas
        // and convert the sections into integers:
        sensors = PApplet.parseInt(split(myString, ','));
    }
    else if (packetType.equals("binary") || packetType.equals("bytestream"))
    {
        int[] resp = new int[NDRIVE*NSENSE];        
        int nread = 0;
        int offset = 0;
        int serialoffset = 2;
        int numberofbufferframe = 5;
        boolean start = false;
        if  (packetType.equals("bytestream")){          
          byte[] buffer = new byte[(NDRIVE*NSENSE+serialoffset)*numberofbufferframe];
          byte[] waitforRemainbuffer = new byte[(NDRIVE*NSENSE+serialoffset)*numberofbufferframe];
          int secondbytesize = 0;          
           while (offset != NDRIVE*NSENSE)
          {
              if (a_port.available() > 0)
              {                  
                  nread = a_port.readBytes(buffer);
                  while(nread<(NDRIVE*NSENSE+2)*2){                    
                    secondbytesize = a_port.readBytes(waitforRemainbuffer);
                    for(int i = nread ; i< nread+secondbytesize || i<(NDRIVE*NSENSE+2)*2; ++i){
                      buffer[i] = waitforRemainbuffer[i-nread];
                    }
                    nread +=secondbytesize;
                  }
                  for (int i = 0; i < nread; i++){
                    if(start==true){
                      //b & 0xff
                      resp[offset] = buffer[i];
                      //resp[offset] = (int)buffer[i];
                      //if (resp[offset] < 0) resp[offset] += 127;
                      offset +=1;
                      if(offset == NDRIVE*NSENSE)break;
                    }
                    else if(buffer[i] == -2){
                      start = true;
                    }                                                            
                  }                  
              }
          }          
        }        
        else{
          byte[] buffer = new byte[NDRIVE*NSENSE];
          while (true)
          {
              if (a_port.available() > 0)
              {
                  
                  nread = a_port.readBytes(buffer);
                  for (int i = 0; i < nread; i++){ 
                    resp[offset + i] = (int)(buffer[i]) & 0xFF;
                  }
                  offset += nread;
              }
              if (offset == NDRIVE*NSENSE) break;
          }
          if (offset != NDRIVE*NSENSE) return false;
        }
        for (int i = 0; i < sensors.length; i++) sensors[i] = resp[i]& 0xff;;
    }   
      
    

    // statistics of sensor data.
    // get min and max value of current frame.
    minFrame = 100000;
    maxFrame = 0;
    sumFrame = 0;
    for (int i = 0; i < sensors.length; i++)
    {
        sumFrame += sensors[i];
        if (sensors[i] < minFrame) minFrame = sensors[i];
        if (sensors[i] > maxFrame) maxFrame = sensors[i];
    }

    // error checking.
    if (sensors.length != MAXDRIVE*MAXSENSE)
    {
        print("Incorrect data: ");
        print(sensors.length);
        println(" bytes");

        // unlock buffer
        is_serial_read = false;
        return false;
    }

    // create information for gui.     
    strSensorData = "";
    sensorFrameRate = millis() - current_time;

    // copy sensor data to variables for gui
    // preprocessing (filtering) is done here.
    int k = 0;
    for (int i = 0; i < data.length; i++)
    {
        for (int j = 0; j < data[0].length; j++)
        {
            // offset removal
            if (doBackgroundNoiseFiltering == true)
            {

                data[driveindex[i]][senseindex[j]] = sensors[k++] - backgroundNoise[driveindex[i]][senseindex[j]];
                if (data[driveindex[i]][senseindex[j]] < 0) data[driveindex[i]][senseindex[j]] = 0;
            } else
            {
                data[driveindex[i]][senseindex[j]] = sensors[k++];
            }

            // thresholding
            if (thresholdValueIndex != 0)
            {
                if (data[driveindex[i]][senseindex[j]] < thresholdValue[thresholdValueIndex]) data[driveindex[i]][senseindex[j]] = 0;
            }

            strSensorData += data[driveindex[i]][senseindex[j]] + ",";
        }
        strSensorData += "\n";
    }

    // debug print
    if (printDebugInfo == true)
    {
        print("DT:");
        print(sensorFrameRate);
        print("ms, ");
        print("SENSOR: (");
        print(data.length);
        print(", ");
        print(data[0].length);
        print("): [");
        for (int i = 0; i < data.length; i++)
        {
            for (int j = 0; j < data[i].length; j++)
            {
                print(data[i][j]);
                print(",");
            }
        }
        println("]");
    }

    // update curren time
    current_time = millis();

    // unlock buffer
    is_serial_read = false;

    return true;
}


// main plotting function
public void surf(int[][] data, boolean grid_on, boolean zdir)
{
    int sx = width/data.length;
    int sy = height/data[0].length;

    if (zdir == false)
    {
        for (int i = 0; i < data.length; i++)
        {
            for (int j = 0; j < data[0].length; j++)
            {
                data[i][j] = -data[i][j];
            }
        }
    }


    noStroke();

    // draw grid
    if (grid_on == true)
    {
        for (int i = 0; i < data.length-1; i++)
        {
            for (int j = 0; j < data[i].length-1; j++)
            {
                // fill the first cell with red color
                stroke(31, 31, 31, 80);
                strokeWeight(3);
                noFill();

                beginShape();
                vertex((i+1)*sx, j*sy, data[i+1][j]);
                vertex((i+1)*sx, (j+1)*sy, data[i+1][j+1]);
                vertex(i*sx, (j+1)*sy, data[i][j+1]);
                endShape();
            }
        }
    }

    // fill grid
    if (fillGrid == true)
    {
        for (int i = 1; i < data.length; i++)
        {
            for (int j = 1; j < data[i].length; j++)
            {
                // fill the first cell with green color
                noStroke();
                
                if (i == 1 && j == 1) fill(0, 255, 0);
                else fill(255, 0, 0);

                beginShape();
                vertex((i-1)*sx, (j-1)*sy, data[i-1][j-1]);
                vertex(i*sx, (j-1)*sy, data[i][j-1]);
                vertex((i-1)*sx, j*sy, data[i-1][j]);
                endShape();

                beginShape();
                vertex(i*sx, (j-1)*sy, data[i][j-1]);
                vertex(i*sx, j*sy, data[i][j]);
                vertex((i-1)*sx, j*sy, data[i-1][j]);
                endShape();
            }
        }
    }
}


// bicubic interpolation of 2D array.
public void interp2d(int[][] x)
{
    int nrowx = x.length;
    int ncolx = x[0].length;
    int nrowy = out_interp2d.length;
    int ncoly = out_interp2d[0].length;

    int x1, x2, x3, x4, y1, y2, y3, y4;
    float v1, v2, v3, v4, v;
    float xx, yy, p, q;

    for (int i = 0; i < nrowy; i++)
    {
        for (int j = 0; j < ncoly; j++)
        {
            xx = (float)(ncolx*j)/(float)(ncoly);
            yy = (float)(nrowx*i)/(float)(nrowy);

            x2 = (int)xx;
            x1 = x2 - 1;
            if (x1 < 0) x1 = 0;
            x3 = x2 + 1;
            if (x3 >= ncolx) x3 = ncolx - 1;
            x4 = x2 + 2;
            if (x4 >= ncolx) x4 = ncolx - 1;
            p = xx - x2;

            y2 = (int)yy;
            y1 = y2 - 1;
            if (y1 < 0) y1 = 0;
            y3 = y2 + 1;
            if (y3 >= nrowx) y3 = nrowx - 1;
            y4 = y2 + 2;
            if (y4 >= nrowx) y4 = nrowx - 1;
            q = yy - y2;

            v1 = cubicci(PApplet.parseFloat(x[y1][x1]), PApplet.parseFloat(x[y1][x2]), PApplet.parseFloat(x[y1][x3]), PApplet.parseFloat(x[y1][x4]), p);
            v2 = cubicci(PApplet.parseFloat(x[y2][x1]), PApplet.parseFloat(x[y2][x2]), PApplet.parseFloat(x[y2][x3]), PApplet.parseFloat(x[y2][x4]), p);
            v3 = cubicci(PApplet.parseFloat(x[y3][x1]), PApplet.parseFloat(x[y3][x2]), PApplet.parseFloat(x[y3][x3]), PApplet.parseFloat(x[y3][x4]), p);
            v4 = cubicci(PApplet.parseFloat(x[y4][x1]), PApplet.parseFloat(x[y4][x2]), PApplet.parseFloat(x[y4][x3]), PApplet.parseFloat(x[y4][x4]), p);

            v = cubicci(v1, v2, v3, v4, q);

            if (v < 0) v = 0; // to avoid negative value.

            out_interp2d[i][j] = PApplet.parseInt(v);
        }
    }
}

// cubic Convolution Interpolation - called by interp2d().
public float cubicci(float v1, float v2, float v3, float v4, float d)
{
    float v, p1, p2, p3, p4;

    p1 = v2;
    p2 = -v1 + v3;
    p3 = 2*(v1-v2) + v3 - v4;
    p4 = -v1 + v2 - v3 + v4;

    v = p1 + d*(p2 + d*(p3 + d*p4));

    return v;
}


public void keyPressed()
{
    // grid fill
    if (key == 'f') fillGrid = !fillGrid;

    // background noise filtering
    if (key == 'n')
    {
        doBackgroundNoiseFiltering = !doBackgroundNoiseFiltering;
        if (doBackgroundNoiseFiltering == true)
        {
            for (int i = 0; i < data.length; i++)
            {
                for (int j = 0; j < data[0].length; j++)
                {
                    backgroundNoise[i][j] = data[i][j];
                }
            }
        }
    }

    // thresholding
    if (key == 't')
    {
        thresholdValueIndex++;
        if (thresholdValueIndex == nThresholdValue) thresholdValueIndex = 0;
    }

    // print debug output
    if (key == 'd') printDebugInfo = !printDebugInfo;

    // circulate plot method
    if (key == 'p')
    {
        plotMethod++;
        if (plotMethod == 3) plotMethod = 0;
    }

    if (key == 'g') drawGrid = !drawGrid;

    if (key == 'x') xDir = !xDir;

    if (key == 'y') yDir = !yDir;

    if (key == 'z') zDir = !zDir;

    if (key == CODED)
    {
        if (keyCode == UP) zscale = 2.0f * zscale;
        if (keyCode == DOWN) zscale = zscale / 2.0f;
    }

    if (key == '2') visualizationType = 2;

    if ((key == '3') && (useOpenGL == true)) visualizationType = 3;

    if (key == 'h') drawHeatmap = !drawHeatmap;

    if (key == ' ') drawMessages = !drawMessages;
    
    if (key == 'm') showMeasurement = !showMeasurement;
    
    if (key == 'u') dataLogger.toggleFrameUnit();
    
    if (key == 'l')
    {
        logIntervalIndex++;
        if (logIntervalIndex == nLogInterval) logIntervalIndex = 0;
    }
    
    if (key == 's')
    {
        squarePlot = !squarePlot;
    }
}


// change applicaion icons
// http://forum.processing.org/one/topic/how-to-change-the-icon-of-the-app.html
public void changeAppIcon(PImage img)
{
    final PGraphics pg = createGraphics(48, 48, JAVA2D);

    pg.beginDraw();
    pg.image(img, 0, 0, 48, 48);
    pg.endDraw();

    frame.setIconImage(pg.image);
}

public void changeAppTitle(String title)
{
    frame.setTitle(title);
}

// draw cylider. this function is based on the code below:
// http://vormplus.be/blog/article/drawing-a-cylinder-with-processing
public void drawCylinder( float x0, float y0, int sides, float r1, float r2, float h, int[] cylinderColor)
{
    fill(cylinderColor[0], cylinderColor[1], cylinderColor[2]);
    noStroke();
    float angle = 360 / sides;
    float halfHeight = h / 2;
    // top
    beginShape();
    for (int i = 0; i < sides; i++) {
        float x = cos( radians( i * angle ) ) * r1 + x0;
        float y = sin( radians( i * angle ) ) * r1 + y0;
        vertex( x, y, 0);
    }
    endShape(CLOSE);
    // bottom
    beginShape();
    for (int i = 0; i < sides; i++) {
        float x = cos( radians( i * angle ) ) * r2 + x0;
        float y = sin( radians( i * angle ) ) * r2 + y0;
        vertex( x, y, h);
    }
    endShape(CLOSE);
    // draw body
    beginShape(TRIANGLE_STRIP);
    for (int i = 0; i < sides + 1; i++) {
        float x1 = cos( radians( i * angle ) ) * r1 + x0;
        float y1 = sin( radians( i * angle ) ) * r1 + y0;
        float x2 = cos( radians( i * angle ) ) * r2 + x0;
        float y2 = sin( radians( i * angle ) ) * r2 + y0;
        vertex( x1, y1, 0);
        vertex( x2, y2, h);
    }
    endShape(CLOSE);
}

public void stop()
{
    if (dataLogger.is_logging == true) dataLogger.stopLog();
}
/* DataLogger.pde
 Log data in CSV format
 Copyright (c) 2014-2016 Kitronyx http://www.kitronyx.com
 contact@kitronyx.com
 GPL V3.0
 */



class DataLogger
{
    String filename_1d;
    String filename_2d;
    PrintWriter pw_1d = null;
    PrintWriter pw_2d = null;;
    boolean is_logging = false;
    int log_index = 0;
    final int buffer_size = 10000;
    int data_length = NDRIVE*NSENSE;
    int ts = 0; // ms
    boolean log_frame_interval = false;
    
    public void createFileNameBasedOnTime()
    {
        String date = String.format("%04d%02d%02dT%02d%02d%02d", year(), month(), day(), hour(), minute(), second());
        println(date);
        filename_1d = dataPath(date + "-1d.csv");
        filename_2d = dataPath(date + "-2d.csv");
    }
    
    public void startLog(int nrow, int ncol)
    {
        try
        {
            pw_1d = new PrintWriter(new FileWriter(filename_1d, true));
            pw_2d = new PrintWriter(new FileWriter(filename_2d, true));
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
        finally
        {
            is_logging = true;
            log_index = 0;
            
            // make header for 1d log data
            if (log_frame_interval != true)
                pw_1d.print("Frame Index,");
            else
                pw_1d.print("Frame Interval(ms),");
            
            for (int i = 0; i < nrow-1; i++)
            {
                for (int j = 0; j < ncol; j++)
                {
                    pw_1d.print("R"+i+"C"+j+",");
                }
            }
            
            for (int j = 0; j < ncol-1; j++)
            {
                pw_1d.print("R"+(nrow-1)+"C"+j+",");
            }
            pw_1d.println("R"+(nrow-1)+"C"+(ncol-1));
        }
    }
    
    public void logData(int[][] d)
    {
        if (is_logging == true)
        {
            if (log_frame_interval == true)
            {
                pw_1d.println(ts + "," + convert2DArrayTo1DString(d));
                pw_2d.println("Frame Interval(ms)" + ts);
            }
            else
            {
                pw_1d.println(log_index + "," + convert2DArrayTo1DString(d));
                pw_2d.println("Frame " + log_index);
            }
            pw_2d.println(convert2DArrayTo2DString(d));
            log_index++;
        }
    }
    
    public String convert2DArrayTo2DString(int[][] d)
    {
        String out = "";
        for (int i = 0; i < d.length-1; i++)
        {
            for (int j = 0; j < d[0].length-1; j++)
            {
                out = out + d[i][j] + ",";
            }
            out = out + d[i][d[0].length-1] + "\n";
        }
        
        for (int j = 0; j < d[0].length-1; j++)
        {
            out = out + d[d.length-1][j] + ",";
        }
        out = out + d[d.length-1][d[0].length-1];
        
        return out;
    }
    
    public String convert2DArrayTo1DString(int[][] d)
    {
        String out = "";
        for (int i = 0; i < d.length-1; i++)
        {
            for (int j = 0; j < d[0].length; j++)
            {
                out = out + d[i][j] + ",";
            }
        }
        
        for (int j = 0; j < d[0].length-1; j++)
        {
            out = out + d[d.length-1][j] + ",";
        }
        out = out + d[d.length-1][d[0].length-1];
        
        return out;
    }
    
    public void stopLog()
    {
        if (pw_1d != null)
        {
            pw_1d.flush();
            pw_1d.close();
        }
        
        if (pw_2d != null)
        {
            pw_2d.flush();
            pw_2d.close();
        }
        
        is_logging = false;
    }
    
    public void logFrameInterval()
    {
        log_frame_interval = true;
    }
    
    public void logFrameIndex()
    {
        log_frame_interval = false;
    }
    
    public void toggleFrameUnit()
    {
        log_frame_interval = !log_frame_interval;
    }
    
    public boolean frameUnit()
    {
        return log_frame_interval; 
    }
    
    public void setTs(int telapsed)
    {
        ts = telapsed;
    }
}
/* gui.pde
 GUI controls
 Copyright (c) 2014-2016 Kitronyx http://www.kitronyx.com
 contact@kitronyx.com
 GPL V3.0
 */


// gui controls
DropdownList dSerial;
Button bStartStop;
Button b2D3D;
Button bLog;
Button bConfig;

public void setupControl()
{
    int controlXPos0 = 10;
    int controlYPos0 = 20;
    int controlWidth = 70;
    int controlHeight = 15;
    int controlXStep = controlWidth + 20;
    int controlYStep = controlHeight + 5;
    int row = 0;
    cp5 = new ControlP5(this);
    
    // 2nd row
    row = 2;
    bStartStop = cp5.addButton("Start (s)", 0, controlXPos0, controlYPos0 + (row-1)*controlYStep, controlWidth, controlHeight);
    
    // 3rd row
    row = 3;
    bLog = cp5.addButton("Start Logging", 0, controlXPos0, controlYPos0 + (row-1)*controlYStep, controlWidth, controlHeight);
    
    // 3rd row
    row = 4;
    bConfig = cp5.addButton("Load INI", 0, controlXPos0, controlYPos0 + (row-1)*(controlYStep), controlWidth, controlHeight); 
    
    // 1st row
    row = 1;
    dSerial = cp5.addDropdownList("Serial").setPosition(controlXPos0, controlYPos0).setWidth(controlWidth);
    dSerial.captionLabel().set("Choose Port");
    for (int i=0; i<Serial.list ().length; i++)
    {
        dSerial.addItem(Serial.list()[i], i);
    }
    
    
    // to be compatible with PeasyCam
    // http://www.sojamo.de/libraries/controlP5/examples/extra/ControlP5withPeasyCam/ControlP5withPeasyCam.pde
    cp5.setAutoDraw(false);
}

public void controlEvent(ControlEvent theEvent)
{
    if (theEvent.isGroup())
    {
        // check if the Event was triggered from a ControlGroup
        if (theEvent.getGroup() == dSerial)
        {
            comPort = dSerial.getItem(PApplet.parseInt(theEvent.getGroup().getValue())).getName();
        }
        
    } 
    else if (theEvent.isController())
    {
        if (theEvent.controller() == bStartStop)
        {
            if (do_data_acquisition) stopDevice();
            else startDevice();
        }
        else if (theEvent.controller() == bLog)
        {
            if (do_data_log) stopLog();
            else startLog();
        }
        else if (theEvent.controller() == bConfig)
        {
            selectInput("Select INI file to load.", "selectINI");
        }
    }
}

public void selectINI(File selection)
{
    if (selection != null)
    {
        if (do_data_log) stopLog();
        if (do_data_acquisition) stopDevice();
        readINI(selection);
        applyINI();
    }
}

public void startDevice()
{
    bStartStop.setCaptionLabel("Stop (s)");
                
    if (!comPort.equals("Not Found"))
    {
        startSerial();
        do_data_acquisition = true;
    }
    else
    {
        do_data_acquisition = false;
    }
}

public void stopDevice()
{
    bStartStop.setCaptionLabel("Start (s)");
    a_port.stop();
    do_data_acquisition = false;
}

public void startLog()
{
    bLog.setCaptionLabel("Stop Logging");
    dataLogger.createFileNameBasedOnTime();
    dataLogger.startLog(data.length, data[0].length);
    do_data_log = true;
}

public void stopLog()
{
    bLog.setCaptionLabel("Start Logging");
    dataLogger.stopLog();
    do_data_log = false;
}

public void drawControl()
{
    // see http://processingjs.org/reference/hint_/
    // for details about hint().
    hint(DISABLE_DEPTH_TEST);
    if (useOpenGL == true) cam.beginHUD();
    cp5.draw();
    if (useOpenGL == true) cam.endHUD();
    hint(ENABLE_DEPTH_TEST);
}

public void drawLogo()
{
    fill(255);
    rect(width/2-100, 0, 200, 50, 0, 0, 100, 100);
    textAlign(CENTER);
    textSize(25);
    fill(0);
    text("KITRONYX", width/2, 30);
    fill(255);
}


public void drawHelp()
{
    textSize(10);
    textAlign(RIGHT, BOTTOM);
    String strHelp = "2/3: switch between 2D/3D\n" +
        "s: Toggle squre and rectangular plot\n" +
        "(3D only) Left Click: Rotate Camera\n" +
        //"(3D only) Right Click: Pan Camera\n" +
        "(3D only) Scroll Wheel: Zoom In/Out\n" +
        "Up/Down: Scale Z Axis\n" +
        //"(3D only) p: Plot Method (Full Interpolation, Separate Interpolation, Cylinder)\n" +
        "(3D only) f: Toggle Grid Fill\n" +
        "(3D only) g: Toggle Grid\n" +
        "(3D only) h: Toggle heatmap\n" +
        "n: Toggle Background Noise Filtering\n" +
        "t: Thresholding (Circulating 0, 10, 20, 30, 40, 50)\n" +
        "d: Toggle Debug Output\n" +
        "x: X direction (normal/reverse)\n" +
        "y: Y direction (normal/reverse)\n" +
        "z: Z direction (normal/reverse)\n" +
        "r: Reset Settings\n" +
        "space: Toggle message display";
        
    text(strHelp, width-10, height-10);
}


public void drawInfo()
{
    textAlign(RIGHT, TOP); 
    fill(255);
    String strInfo = "Port: " + comPort + "\n" +
        "Baud Rate: " + baudRate + "\n" +
        "Frame Rate: " + sensorFrameRate + " (ms)\n" +
        "Frame Rate: " + nf(1000/sensorFrameRate,2,2) + "(hz)\n" +
        "Data Size: (" + data.length + ", " + data[0].length + ")\n" +
        "Active Plot Range: (" + ACTIVERANGE[0] + ", " + ACTIVERANGE[1] + ", " + ACTIVERANGE[2] + ", " + ACTIVERANGE[3] + ")\n" +
        "Z Axis Scale: " + zscale + "\n" +
        "Minimum Value (Current Frame): " + minFrame + "\n" +
        "Maximum Value (Current Frame): " + maxFrame + "\n" +
        "Sum Value (Current Frame): " + sumFrame + "\n" +
        "Background Noise Filtering: " + doBackgroundNoiseFiltering + "\n" +
        "Threshold Value: " + thresholdValue[thresholdValueIndex] + "\n" +
        "Camera Eye: (" + eyeX + ", " + eyeY + ", " + eyeZ + ")\n" + 
        "Translate: (" + transX + ", " + transY + ",)\n" +
        "X direction normal: " + xDir + "\n" +
        "Y direction normal: " + yDir + "\n" +
        "Z direction normal: " + zDir + "\n" +
        "Frame Interval: " + dataLogger.frameUnit() + "\n" +
        "Log Interval: " + logInterval[logIntervalIndex];
    text(strInfo, width-10, 10);
}


public void drawMeasurement()
{
    textSize(10);
    textAlign(LEFT, BOTTOM);
    // print ordered matrix data - coincident with the sensor structure
    // http://stackoverflow.com/questions/409784/whats-the-simplest-way-to-print-an-array
    text(Arrays.deepToString(data).replaceAll("],", "],\r\n"), 10, height-10);
}

public void drawCopyright()
{
    fill(255);
    textAlign(CENTER, BOTTOM);
    textSize(12);
    text("Copyright(c) 2014-2017 Kitronyx Inc. All rights reserved", width/2, height-10);
}

public void drawGraph()
{
    getDataToDraw();
    
    // data visualization.
    // these functions use `data_to_draw` as a base data.
    pushMatrix(); 
    if (visualizationType == 2)
    {
        if (useOpenGL == true) cam.beginHUD(); // do not use peasycam.
        visualization2D();
        if (useOpenGL == true) cam.endHUD();
    }
    else if (visualizationType == 3)
    {
        rotateX(radians(45));
        visualization3D();
    }
    popMatrix();
}

public void getDataToDraw()
{
    // decorate data to visualize using obtained sensor data.
    // here data in the range of display is picked up and
    // stored in `data_to_draw`.
    int drive_index_to_draw;
    int sense_index_to_draw;
    for (int i = ACTIVERANGE[0]-1; i < ACTIVERANGE[1]; i++)
    {
        for (int j = ACTIVERANGE[2]-1; j < ACTIVERANGE[3]; j++)
        {
            if (xDir == false)
            {
                sense_index_to_draw = ACTIVERANGE[3]-1-j;
            }
            else sense_index_to_draw = j;
            
            if (yDir == false)
            {
                drive_index_to_draw = ACTIVERANGE[1]-1-i;
            }
            else drive_index_to_draw = i;
            
            data_to_draw[i - ACTIVERANGE[0] + 1][j - ACTIVERANGE[2] + 1] = PApplet.parseInt(zscale*PApplet.parseFloat(data[drive_index_to_draw][sense_index_to_draw]));
        }
    }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "snowforce" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
